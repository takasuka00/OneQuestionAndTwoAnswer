package com.takasuka.forest

import android.app.Application

class CustomApplication :Application() {
    companion object {
        var today = 0
        var allday = 0
        var selectedAction = ""
        var selectedBl = false
    }
    override fun onCreate() {
        super.onCreate()
    }
}