package com.takasuka.forest.activity

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.takasuka.availabefiles.data.SQLite.DatabaseEditor
import com.takasuka.everydaytask.EditKey
import com.takasuka.everydaytask.Key
import com.takasuka.forest.CustomApplication.Companion.selectedAction
import com.takasuka.forest.R
import kotlinx.android.synthetic.main.activity_edit.*

class EditActivity() : AppCompatActivity() {
    private lateinit var editor:DatabaseEditor
    private lateinit var data:Map<String,Any?>
    private var selectedId :Long = -1L
    private lateinit var radioId :ArrayList<Int>
    private lateinit var editKey :EditKey
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        editor =   DatabaseEditor(applicationContext)
        editKey = EditKey(applicationContext)
        radioId = arrayListOf<Int>(
            R.id.radioButton01,
            R.id.radioButton02,
            R.id.radioButton03,
            R.id.radioButton04,
            R.id.radioButton05
            )
        val intents = getIntent()
        selectedId = intents.getLongExtra("key",-1L)
        val maxId =  editor.getMaxId().toInt()
        view_1.text = "id:"+ (maxId+1).toString()
        if(selectedId!=-1L){
            val tmp = editor.getData(selectedId)
            if(tmp!= null)
                data = tmp
            questionEditText.setText(data["question"] as String)
            answerEditText.setText(data["answer"] as String)

            if(secondAnswerEditText.text.toString() != "null"){
                secondAnswerEditText.setText(data["second"] as String)
                switch2.isChecked = true
            }
            view_1.text = "id:" + data["_id"]
            addressRadioGroup.check(radioId[data["address"].toString().toInt()])
        }
        else {
            view_1.text = "id:" + (maxId + 1).toString()
            addressRadioGroup.check(radioId[editKey.readInt(Key.ADDRESSCONECTOR)])
        }


        if(switch2.isChecked){
            switch2.setTextColor(Color.rgb(0,0,0))
            secondAnswerEditText.isEnabled = true
        }else{
            switch2.setTextColor(Color.rgb(150,150,150))
            secondAnswerEditText.isEnabled = false
        }
        switch2.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                switch2.setTextColor(Color.rgb(0,0,0))
                secondAnswerEditText.isEnabled = true
            }else{
                switch2.setTextColor(Color.rgb(150,150,150))
                secondAnswerEditText.isEnabled = false
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return super.onSupportNavigateUp()
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId == android.R.id.home){
            saveData(questionEditText.text.toString(), answerEditText.text.toString())
            selectedAction = ""
            Handler().postDelayed({finish()},10L)
        }else if( item.itemId == R.id.context_action_delete){
            if(selectedId != -1L){
                editor.deleteColumn(selectedId)
        }
            Handler().postDelayed({finish()},10L)}
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_context, menu)
        return true
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when(keyCode){
            KeyEvent.KEYCODE_BACK->{
                saveData(questionEditText.text.toString(), answerEditText.text.toString())
                selectedAction = ""
                Handler().postDelayed({finish()},10L)
                return false
            }

        }
        return super.onKeyDown(keyCode, event)
    }


    private fun saveData(
        question :String
        ,answer:String
    ){
        if(!question.isNullOrBlank()){
            var saveData = mutableMapOf<String,Any?>()
        if(selectedId == -1L) {
            saveData.put("_id" , -1L)
        }else {
            saveData = data as MutableMap
        }
            saveData.put("question" , question)
            saveData.put("answer" , answer)
            if(switch2.isChecked && secondAnswerEditText.text.toString() != "")
                saveData.put("second",secondAnswerEditText.text)
            else
                saveData.put("second","null")
            val selectedRadioId = addressRadioGroup.checkedRadioButtonId
            for(i in 0..radioId.size-1){
                if(radioId[i] == selectedRadioId) {
                    saveData.put("address", i)
                    editKey.writeInt(Key.ADDRESSCONECTOR,i)
                }
            }
            editor.insertColumn(saveData)
            Toast.makeText(applicationContext, R.string.data_save_toast, Toast.LENGTH_LONG).show()
        }
    }
    override fun onDestroy() {
        editor.closeHelper()
        super.onDestroy()
    }


}